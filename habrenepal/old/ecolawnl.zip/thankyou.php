<?
require "Config.php";
$PageTitle="Thank You!";
$Message="Your request has been submitted.";
$Template="htmls/DisplayMessage.html";
include "htmls/Home.html";

?>