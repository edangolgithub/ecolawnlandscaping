<?
require "Config.php";
$PageTitle="";
$Template="htmls/Portfolio.html";
include "htmls/Home.html";

?>